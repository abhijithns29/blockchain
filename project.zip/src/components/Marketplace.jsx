import React, { useEffect, useState } from "react";
import LandDetailsModal from "./LandDetailsModal";

const PropertyForm = () => {
  const [salePrice, setSalePrice] = useState(0);
  const [features, setFeatures] = useState([]);
  const [featureInput, setFeatureInput] = useState("");
  const [amenities, setAmenities] = useState([]);
  const [amenityInput, setAmenityInput] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("salePrice", salePrice);
    formData.append("features", JSON.stringify(features));
    formData.append("amenities", JSON.stringify(amenities));
    // ...submit form data
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* ...existing form fields... */}

      {/* Price input */}
      <input
        type="number"
        min="1"
        step="0.01"
        value={salePrice}
        onChange={(e) => setSalePrice(Number(e.target.value))}
        required
      />

      {/* Features input */}
      <label>Features</label>
      <div>
        <input
          type="text"
          value={featureInput}
          onChange={(e) => setFeatureInput(e.target.value)}
          placeholder="Add a feature"
        />
        <button
          type="button"
          onClick={() => {
            if (featureInput.trim() !== "") {
              setFeatures([...features, featureInput.trim()]);
              setFeatureInput("");
            }
          }}
        >
          Add
        </button>
      </div>
      <ul>
        {features.map((f, i) => (
          <li key={i}>
            {f}{" "}
            <button
              type="button"
              onClick={() =>
                setFeatures(features.filter((_, idx) => idx !== i))
              }
            >
              ❌
            </button>
          </li>
        ))}
      </ul>

      {/* Amenities input */}
      <label>Amenities</label>
      <div>
        <input
          type="text"
          value={amenityInput}
          onChange={(e) => setAmenityInput(e.target.value)}
          placeholder="Add an amenity"
        />
        <button
          type="button"
          onClick={() => {
            if (amenityInput.trim() !== "") {
              setAmenities([...amenities, amenityInput.trim()]);
              setAmenityInput("");
            }
          }}
        >
          Add
        </button>
      </div>
      <ul>
        {amenities.map((a, i) => (
          <li key={i}>
            {a}{" "}
            <button
              type="button"
              onClick={() =>
                setAmenities(amenities.filter((_, idx) => idx !== i))
              }
            >
              ❌
            </button>
          </li>
        ))}
      </ul>

      {/* ...existing form fields... */}
    </form>
  );
};

export default function Marketplace() {
  const [lands, setLands] = useState([]);
  const [selected, setSelected] = useState(null);
  const [selectedLandView, setSelectedLandView] = useState(null);

  useEffect(() => {
    fetch("/api/lands/marketplace")
      .then((r) => r.json())
      .then((data) => setLands(data.lands || data)) // adapt to your API shape
      .catch((e) => console.error("marketplace fetch error", e));
  }, []);

  return (
    <div>
      <h1>Marketplace</h1>
      <div className="grid">
        {lands.map((land) => (
          <div key={land._id || land.id} className="card">
            <h3>{land.surveyNumber || land._id}</h3>
            <p>Price: {land.marketInfo?.askingPrice || "—"}</p>
            <button
              onClick={() => setSelectedLandView(land)}
              className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              {/* <Eye className="h-4 w-4 mr-1" /> */}
              View Details
            </button>
          </div>
        ))}
      </div>
      {/* Modal for viewing details */}
      {selectedLandView && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Land Details</h2>
              <button
                onClick={() => setSelectedLandView(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
            <p>
              <strong>Survey Number:</strong> {selectedLandView.surveyNumber}
            </p>
            <p>
              <strong>Village:</strong> {selectedLandView.village}
            </p>
            <p>
              <strong>District:</strong> {selectedLandView.district}
            </p>
            <p>
              <strong>Area:</strong>{" "}
              {/* formatArea(selectedLandView.area) or just */}
              {selectedLandView.area}
            </p>
            <p>
              <strong>Type:</strong> {selectedLandView.landType}
            </p>
            <p>
              <strong>Status:</strong> {selectedLandView.status}
            </p>
            {selectedLandView.marketInfo && (
              <div className="mt-3">
                <p>
                  <strong>Asking Price:</strong> {selectedLandView.marketInfo.askingPrice}
                </p>
                <p>
                  <strong>Description:</strong> {selectedLandView.marketInfo.description}
                </p>
                {selectedLandView.marketInfo.features?.length > 0 && (
                  <div>
                    <strong>Features:</strong>
                    <ul className="list-disc ml-5">
                      {selectedLandView.marketInfo.features.map((f, i) => (
                        <li key={i}>{f}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {selectedLandView.marketInfo.nearbyAmenities?.length > 0 && (
                  <div>
                    <strong>Nearby Amenities:</strong>
                    <ul className="list-disc ml-5">
                      {selectedLandView.marketInfo.nearbyAmenities.map((a, i) => (
                        <li key={i}>{a}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {selectedLandView.marketInfo.images?.length > 0 && (
                  <div className="mt-3">
                    <strong>Images:</strong>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {selectedLandView.marketInfo.images.map((img, i) => (
                        <img
                          key={i}
                          src={img}
                          alt={`Land ${i}`}
                          className="w-full h-32 object-cover rounded-md"
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
      {/* {selected && (
        <LandDetailsModal land={selected} onClose={() => setSelected(null)} />
      )} */}
    </div>
  );
}