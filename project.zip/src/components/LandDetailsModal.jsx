import React from "react";

export default function LandDetailsModal({ land, onClose }) {
  if (!land) return null;
  const mi = land.marketInfo || {};

  return (
    <div className="modal-backdrop">
      <div className="modal">
        <button onClick={onClose}>Close</button>
        <h2>Land: {land.surveyNumber || land._id}</h2>
        <p><strong>Price:</strong> {mi.askingPrice ?? "N/A"}</p>
        <p><strong>Description:</strong> {mi.description ?? "No description"}</p>
        {mi.features?.length > 0 && (
          <div>
            <h4>Features</h4>
            <ul>{mi.features.map((f, i) => <li key={i}>{f}</li>)}</ul>
          </div>
        )}
        {mi.nearbyAmenities?.length > 0 && (
          <div>
            <h4>Nearby Amenities</h4>
            <ul>{mi.nearbyAmenities.map((a, i) => <li key={i}>{a}</li>)}</ul>
          </div>
        )}
        <div>
          <h4>Images</h4>
          {mi.imageUrls?.length > 0 ? (
            <div className="images-grid">
              {mi.imageUrls.map((url, i) => (
                <a key={i} href={url} target="_blank" rel="noopener noreferrer">
                  <img src={url} alt={`land-${i}`} style={{ width:120, height:80, objectFit:"cover" }} />
                </a>
              ))}
            </div>
          ) : (
            <p>No images</p>
          )}
        </div>
      </div>
    </div>
  );
}
